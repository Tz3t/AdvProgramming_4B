public class subscription {
  String name;
   int price;
   int months;
   int pricetotal;//for total price of one, this is then to be added together with other subscription totals to produce a totalTotalPrice
  
  public subscription(String name, int price, int months) {
    this.name = name;
    this.price = price;
    this.months = months;
  }
  public String details() {
    String details = "Subscription: " + name + "\nPrice: " + price + "\nMonths: " + months;
    return details;
  }
  public String getName() {
    return name;
  }
  public int getPrice() {
    return price;
  }
  public int getMonths() {
    return months;
  }
  public int getTotalPrice() {
    pricetotal = price * months;
    return pricetotal;
  }
}